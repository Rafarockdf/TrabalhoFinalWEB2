INSERT INTO tipos_atividades_fisicas(ds_atividade) VALUES ('Musculação');
INSERT INTO tipos_atividades_fisicas(ds_atividade) VALUES ('Pilates');
INSERT INTO tipos_atividades_fisicas(ds_atividade) VALUES ('Corrida');
INSERT INTO tipos_atividades_fisicas(ds_atividade) VALUES ('Natação');